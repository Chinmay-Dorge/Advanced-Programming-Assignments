public class Main {
    public static void main(String[] args){
        Football f = new Football();
        f.play();        // overriding
        f.play(3,4);     // overloading
    }
}