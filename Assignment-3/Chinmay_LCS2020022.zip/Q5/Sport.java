public class Sport{
    public void play(){
        System.out.println("Playing sport");
    }
}