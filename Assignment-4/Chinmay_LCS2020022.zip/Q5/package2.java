package pack2;
public class package2 {
    public void getDetails(){
        System.out.println("This is package 2");
    }
}