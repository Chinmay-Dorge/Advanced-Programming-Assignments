package pack1;
public class package1 {
    public void getDetails(){
        System.out.println("This is package 1");
    }
}