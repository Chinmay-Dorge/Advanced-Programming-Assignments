import car.Car;
public class Main {
    public static void main(String[] args){
        Car obj = new Car("Tesla" , "Electricity");
        obj.displayProperties();
    }
}